public class Robin extends Bird implements Sounds
{
	public void sound()
	{
		System.out.println( "chirp chirp!" );
	
	}//end sound

	public void fly()
	{
		System.out.println( "I believe I can touch the sky!");
	
	}//end fly

}//end class