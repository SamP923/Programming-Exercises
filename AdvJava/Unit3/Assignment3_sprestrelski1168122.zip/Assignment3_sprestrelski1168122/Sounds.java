public interface Sounds
{
	void sound();
	//the only common behavior among animals

}//end interface