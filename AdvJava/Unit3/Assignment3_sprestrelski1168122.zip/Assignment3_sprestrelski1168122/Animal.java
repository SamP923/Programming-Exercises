public abstract class Animal
{
	double weight;
	double age;
	//variables for all animals

	public void setWeight( double w )
	{
		weight = w;
	
	}//end setWeight

	public void setAge( double a )
	{
		age = a;

	}//end setAge

	public double getWeight()
	{
		return weight;
	
	}//end getWeight

	public double getAge()
	{
		return age;

	}//end getAge

}//end class