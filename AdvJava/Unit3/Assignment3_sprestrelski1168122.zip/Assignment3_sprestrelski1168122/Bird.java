public abstract class Bird extends Animal
{
	public abstract void fly();
	//behavior specific to only birds

}//end class