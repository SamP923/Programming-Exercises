public class Bluebird extends Bird implements Sounds
{
	public void sound()
	{
		System.out.println( "eek eek eek!");
	
	}//end sound

	public void fly()
	{
		System.out.println( "I believe I can fly!");
	
	}//end fly

}//end class