public abstract class Dog extends Animal
{
	public abstract void sitUp();
	public abstract void lieDown();
	//methods common among dogs only

}//end class