public class Chihuahua extends Dog implements Sounds
{
	public void sound()
	{
		System.out.println( "Yo quiero taco bell.");

	}//end sound
	
	public void sitUp()
	{
		System.out.println( "Chihuahua sat up!");
	
	}//end situp

	public void lieDown()
	{
		System.out.println( "Chihuahua lay down!");
	
	}//end liedown

}//end class