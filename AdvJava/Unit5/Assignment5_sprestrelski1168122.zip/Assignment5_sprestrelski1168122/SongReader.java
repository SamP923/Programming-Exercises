public interface SongReader
{
	Song readSong();
}