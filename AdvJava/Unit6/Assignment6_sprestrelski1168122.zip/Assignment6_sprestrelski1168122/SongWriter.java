public interface SongWriter
{
	void writeSong( Song s );
}