function activated(){
	window.alert('Ow!');
	window.alert('Please don\'t do that again :(');
}

document.getElementById("activate_me").onclick = activated;
/* Samantha Prestrelski
   1168122 */