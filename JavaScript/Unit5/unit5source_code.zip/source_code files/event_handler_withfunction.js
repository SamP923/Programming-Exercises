function date_and_bye(){
	alert("Today is "+ Date());
	alert("Bye!");
}