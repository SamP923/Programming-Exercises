var my_win = window.innerWidth;
if ( my_win >= 1000 ) 
{
	window.location = "http://www.scripttheweb.com/js/";
}
else 
{
	window.location = "http://www.scripttheweb.com/css/";
}